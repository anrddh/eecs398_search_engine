pip3 install virtualenv
python3 -m venv env
source env/bin/activate
pip install --upgrade pip
pip install nltk
pip install requests
pip install beautifulsoup4
